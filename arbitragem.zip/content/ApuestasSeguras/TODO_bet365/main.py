import requests
import random
import json
import os
from bs4 import BeautifulSoup



from herramientas_scraping import herramientas_proxies
from herramientas_scraping import herramientas_headers
from herramientas_scraping import proxyscan
from herramientas_scraping import scraperapi
from herramientas_scraping.mis_funciones import *


import bet3653

#get_proxies.download_proxies_free_proxy2()

from nuevos import apuestas2

from API import web

'''
web.app.run(host='0.0.0.0',port=random.randint(2000, 9000),debug=False)
'''

if __name__=='__main__':
	a=apuestas2.Apuestas()
	